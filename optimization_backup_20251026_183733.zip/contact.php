<?php
/**
 * Contact Page - APS Dream Homes Pvt Ltd - Enhanced Version
 * Professional contact page with comprehensive information and multiple contact methods
 */
// Define constant to allow database connection
if (!defined('INCLUDED_FROM_MAIN')) {
    define('INCLUDED_FROM_MAIN', true);
} 

// Include database connection
require_once 'includes/db_connection.php';

// Process form submission
$form_submitted = false;
$form_success = false;
$form_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {
    // Validate form data
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
    
    // Basic validation
    if (empty($name) || empty($email) || empty($phone) || empty($message)) {
        $form_error = "सभी आवश्यक फ़ील्ड भरें";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $form_error = "कृपया एक वैध ईमेल पता दर्ज करें";
    } else {
        try {
            // Insert into database
            $sql = "INSERT INTO contact_submissions (name, email, phone, subject, message, submission_date, ip_address) 
                    VALUES (:name, :email, :phone, :subject, :message, NOW(), :ip)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':phone' => $phone,
                ':subject' => $subject ?: 'Website Contact Form',
                ':message' => $message,
                ':ip' => $_SERVER['REMOTE_ADDR']
            ]);
            
            // Send notification email to admin
            // Note: Implement email sending functionality here
            
            $form_submitted = true;
            $form_success = true;
        } catch (PDOException $e) {
            $form_submitted = true;
            $form_error = "फॉर्म जमा करने में त्रुटि हुई। कृपया बाद में पुन: प्रयास करें।";
            error_log("Contact form error: " . $e->getMessage());
        }
    }
}

// Set page variables for layout
$page_title = 'Contact Us - APS Dream Homes Pvt Ltd - Real Estate Services in Gorakhpur';
$page_description = 'Contact APS Dream Homes Pvt Ltd for all your real estate needs in Gorakhpur. Call +91-9554000001, visit our office, or fill out our contact form. Professional real estate services with 8+ years of experience.';

try {
    global $pdo;
    $conn = $pdo;

    // Get company settings from database
    $settings_sql = "SELECT setting_name, setting_value FROM site_settings WHERE setting_name IN ('company_name', 'company_phone', 'company_email', 'company_address', 'working_hours')";
    $settings_stmt = $conn->prepare($settings_sql);
    $settings_stmt->execute();
    $settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

} catch (PDOException $e) {
    $settings = [];
    $error_message = "Unable to load company information.";
}
?>

<style>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- AOS Animation -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 80px 0;
            text-align: center;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .contact-method {
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            text-align: center;
            color: white;
        }

        .contact-method:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .phone-contact {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .email-contact {
            background: linear-gradient(135deg, #007bff, #6610f2);
        }

        .address-contact {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
        }

        .contact-icon {
            width: 80px;
            height: 80px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin: 0 auto 20px;
            font-size: 2rem;
            backdrop-filter: blur(10px);
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
        }

        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            padding: 15px 35px;
            border-radius: 30px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: linear-gradient(45deg, #764ba2, #667eea);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
        }

        .info-card {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border-left: 5px solid #667eea;
        }

        .service-areas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .service-area-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .service-area-card:hover {
            transform: translateY(-5px);
        }

        .faq-item {
            background: white;
            border-radius: 10px;
            margin-bottom: 20px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .accordion-button {
            background: #f8f9fa;
            color: #333;
            font-weight: 600;
        }

        .accordion-button:not(.collapsed) {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }

        .accordion-button:focus {
            box-shadow: 0 0 0 0.25rem rgba(102, 126, 234, 0.25);
        }

        .map-placeholder {
            background: #e9ecef;
            border-radius: 15px;
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 1.1rem;
        }

        .contact-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 30px;
        }

        .contact-card:hover {
            transform: translateY(-5px);
        }

        .stats-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 60px 0;
        }

        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 20px;
            padding: 40px 30px;
            text-align: center;
            transition: transform 0.3s ease;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }

        .stats-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }

        .testimonial-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            border-left: 5px solid #ffc107;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-home me-2"></i>APS Dream Homes Pvt Ltd
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="properties.php">Properties</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="contact.php">Contact</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="tel:<?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>" class="btn btn-outline-success me-2">
                        <i class="fas fa-phone me-1"></i><?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>
                    </a>
                    <a href="customer_login.php" class="btn btn-outline-light me-2">Login</a>
                    <a href="customer_registration.php" class="btn btn-success">Register</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="section-title">Get In Touch</h1>
                    <p class="lead mb-4">
                        Have questions about a property or need expert advice?<br>
                        We're here to help you every step of the way.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Contact Methods -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4" data-aos="fade-up">
                    <div class="contact-method phone-contact">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <h4>Call Us Directly</h4>
                        <h3><a href="tel:<?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>" class="text-white text-decoration-none">
                            <?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>
                        </a></h3>
                        <p class="mb-0">Our phone lines are open during business hours. For urgent matters, call us anytime.</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="contact-method email-contact">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <h4>Email Us</h4>
                        <h5><a href="mailto:<?php echo $settings['company_email'] ?? 'info@apsdreamhomes.com'; ?>" class="text-white text-decoration-none">
                            <?php echo $settings['company_email'] ?? 'info@apsdreamhomes.com'; ?>
                        </a></h5>
                        <p class="mb-0">Send us an email and we'll get back to you within 24 hours.</p>
                    </div>
                </div>

                <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="contact-method address-contact">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h4>Visit Our Office</h4>
                        <p class="mb-0">
                            <?php echo $settings['company_address'] ?? '123, Kunraghat Main Road, Near Railway Station, Gorakhpur, UP - 273008'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Form & Information -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="card contact-card">
                        <div class="card-body p-5">
                            <h3 class="mb-4">Send Us a Message</h3>
                            <p class="text-muted mb-4">Fill out the form below and we'll get back to you within 24 hours</p>

                            <form id="contactForm" method="POST" action="<?php echo BASE_URL; ?>/submit/contact">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="name" class="form-label fw-bold">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="name" name="name" required placeholder="Enter your full name">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label fw-bold">Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" id="email" name="email" required placeholder="your.email@example.com">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="phone" class="form-label fw-bold">Phone Number</label>
                                        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Your contact number">
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="contact_type" class="form-label fw-bold">Contact Type</label>
                                        <select class="form-select" id="contact_type" name="contact_type">
                                            <option value="General Inquiry">General Inquiry</option>
                                            <option value="Property Inquiry">Property Inquiry</option>
                                            <option value="Investment Consultation">Investment Consultation</option>
                                            <option value="Site Visit Request">Site Visit Request</option>
                                            <option value="Technical Support">Technical Support</option>
                                            <option value="Feedback">Feedback</option>
                                            <option value="Partnership">Partnership</option>
                                            <option value="Legal Documentation">Legal Documentation</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="budget" class="form-label fw-bold">Budget Range</label>
                                        <select class="form-select" id="budget" name="budget">
                                            <option value="">Select Budget Range</option>
                                            <option value="Under 25L">Under ₹25 Lakh</option>
                                            <option value="25L-50L">₹25L - ₹50L</option>
                                            <option value="50L-1Cr">₹50L - ₹1Cr</option>
                                            <option value="1Cr-2Cr">₹1Cr - ₹2Cr</option>
                                            <option value="Above 2Cr">Above ₹2Cr</option>
                                        </select>
                                    </div>

                                    <div class="col-md-6 mb-3">
                                        <label for="property_type" class="form-label fw-bold">Property Type Interest</label>
                                        <select class="form-select" id="property_type" name="property_type">
                                            <option value="">Select Property Type</option>
                                            <option value="Apartment">Apartment</option>
                                            <option value="Villa">Villa</option>
                                            <option value="Plot">Plot</option>
                                            <option value="Commercial">Commercial</option>
                                            <option value="House">Independent House</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="subject" class="form-label fw-bold">Subject <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="subject" name="subject" required placeholder="Brief description of your inquiry">
                                </div>

                                <div class="mb-4">
                                    <label for="message" class="form-label fw-bold">Message <span class="text-danger">*</span></label>
                                    <textarea class="form-control" id="message" name="message" rows="6" required placeholder="Please provide detailed information about your requirements, questions, or feedback. Our team will get back to you within 24 hours."></textarea>
                                </div>

                                <div class="form-check mb-4">
                                    <input class="form-check-input" type="checkbox" id="newsletter" name="newsletter">
                                    <label class="form-check-label" for="newsletter">
                                        Subscribe to our newsletter for latest property updates and exclusive deals
                                    </label>
                                </div>

                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        <i class="fas fa-paper-plane me-2"></i>Send Message
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="info-card">
                        <h4 class="mb-4">Contact Information</h4>
                        <p class="mb-4">Multiple ways to reach us</p>

                        <div class="mb-4">
                            <h6><i class="fas fa-map-marker-alt me-2 text-primary"></i>Visit Our Office</h6>
                            <p class="mb-0">
                                <?php echo $settings['company_address'] ?? '123, Kunraghat Main Road, Near Railway Station, Gorakhpur, UP - 273008'; ?>
                            </p>
                        </div>

                        <div class="mb-4">
                            <h6><i class="fas fa-clock me-2 text-primary"></i>Business Hours</h6>
                            <p class="mb-0">
                                <?php echo $settings['working_hours'] ?? 'Mon-Sat: 9:30 AM - 7:00 PM, Sun: 10:00 AM - 5:00 PM'; ?>
                            </p>
                        </div>

                        <div class="mb-4">
                            <h6><i class="fas fa-phone me-2 text-primary"></i>Call Us</h6>
                            <p class="mb-0">
                                <a href="tel:<?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>" class="text-decoration-none fw-bold">
                                    <?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>
                                </a>
                            </p>
                            <small class="text-muted">Available during business hours</small>
                        </div>

                        <div class="mb-4">
                            <h6><i class="fas fa-envelope me-2 text-primary"></i>Email Us</h6>
                            <p class="mb-0">
                                <a href="mailto:<?php echo $settings['company_email'] ?? 'info@apsdreamhomes.com'; ?>" class="text-decoration-none">
                                    <?php echo $settings['company_email'] ?? 'info@apsdreamhomes.com'; ?>
                                </a>
                            </p>
                            <small class="text-muted">Response within 24 hours</small>
                        </div>

                        <div class="mb-4">
                            <h6><i class="fas fa-whatsapp me-2 text-success"></i>WhatsApp</h6>
                            <p class="mb-0">
                                <a href="https://wa.me/919554000001" class="text-decoration-none text-success fw-bold" target="_blank">
                                    Chat on WhatsApp
                                </a>
                            </p>
                            <small class="text-muted">Quick responses available</small>
                        </div>
                    </div>

                    <div class="card contact-card">
                        <div class="card-body p-4">
                            <h5 class="mb-3">We'd Love to Hear From You</h5>
                            <p class="text-muted mb-0">Send us a message and we'll respond as soon as possible.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Service Areas -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2>Our Service Areas</h2>
                <p class="lead text-muted">We serve clients across multiple cities and regions</p>
            </div>

            <div class="service-areas">
                <div class="service-area-card">
                    <div class="bg-primary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-building"></i>
                    </div>
                    <h6 class="text-primary mb-2">Main Office</h6>
                    <h5>Gorakhpur</h5>
                    <p class="mb-0 text-muted">Our headquarters and primary service area</p>
                </div>

                <div class="service-area-card">
                    <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-building"></i>
                    </div>
                    <h6 class="text-primary mb-2">Branch Office</h6>
                    <h5>Lucknow</h5>
                    <p class="mb-0 text-muted">Regional office for central UP operations</p>
                </div>

                <div class="service-area-card">
                    <div class="bg-info text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h6 class="text-primary mb-2">Service Area</h6>
                    <h5>Varanasi</h5>
                    <p class="mb-0 text-muted">Eastern UP service coverage</p>
                </div>

                <div class="service-area-card">
                    <div class="bg-warning text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h6 class="text-primary mb-2">Service Area</h6>
                    <h5>Allahabad</h5>
                    <p class="mb-0 text-muted">Central UP service area</p>
                </div>

                <div class="service-area-card">
                    <div class="bg-secondary text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 50px; height: 50px;">
                        <i class="fas fa-expand-arrows-alt"></i>
                    </div>
                    <h6 class="text-primary mb-2">Extended Service</h6>
                    <h5>Other Cities</h5>
                    <p class="mb-0 text-muted">Available on request</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Interactive Map Placeholder -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2>Find Us</h2>
                <p class="lead text-muted">Visit our office or explore our service areas</p>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="map-placeholder">
                        <div class="text-center">
                            <i class="fas fa-map-marked-alt fa-3x mb-3 text-primary"></i>
                            <h4>Interactive Map</h4>
                            <p class="mb-2">Our office location and service areas</p>
                            <small class="text-muted">Google Maps integration coming soon</small>
                            <div class="mt-3">
                                <a href="https://maps.google.com/?q=123, Kunraghat Main Road, Near Railway Station, Gorakhpur, UP - 273008" class="btn btn-primary btn-sm" target="_blank">
                                    <i class="fas fa-directions me-1"></i>View on Google Maps
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2>Frequently Asked Questions</h2>
                <p class="lead text-muted">Quick answers to common questions</p>
            </div>

            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                How quickly can I expect a response?
                            </button>
                        </h5>
                        <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                We typically respond to all inquiries within 24 hours during business days. For urgent matters, please call us directly at <?php echo $settings['company_phone'] ?? '+91-9554000001'; ?>. Emergency support is available 24/7.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                Do you charge any fees for consultations?
                            </button>
                        </h5>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Initial consultations and property viewings are completely free. We only charge fees when you decide to proceed with a purchase or rental agreement. Our consultation services include market analysis, property evaluation, and investment guidance.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                Can you help with property financing?
                            </button>
                        </h5>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, we work with multiple banks and financial institutions to help you secure the best financing options for your property purchase. Our team can guide you through the entire loan process, documentation requirements, and help you get pre-approved for loans.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq4">
                                What documents do I need to buy a property?
                            </button>
                        </h5>
                        <div id="faq4" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                You'll need ID proof (Aadhaar/PAN), address proof, income proof (salary slips/IT returns), bank statements (last 6 months), and passport-sized photographs. Our legal team will guide you through the complete documentation process and ensure everything is in order.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq5">
                                Do you provide after-sales support?
                            </button>
                        </h5>
                        <div id="faq5" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, we provide comprehensive after-sales support including property management services, maintenance coordination, legal assistance for registration, and ongoing customer support. Our relationship with customers continues long after the sale is completed.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <h5 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq6">
                                Can I schedule a site visit?
                            </button>
                        </h5>
                        <div id="faq6" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Absolutely! You can schedule a site visit by calling us, sending an email, or filling out the contact form above. We'll arrange a convenient time for you to visit our properties and have our experts show you around and answer all your questions.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>