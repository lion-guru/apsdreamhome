<?php
// Modern, AI-powered, feature-rich dashboard for Employees (2025 best practices)
require_once 'header.php';
session_start();
if (!isset($_SESSION['uid']) || $_SESSION['utype'] !== 'employee') {
    header('Location: login.php');
    exit();
}
// Example employee stats (replace with real queries)
$employee_name = htmlspecialchars($_SESSION['name'] ?? 'Employee');
$stats = [
    'tasks_today' => 4,
    'attendance_days' => 18,
    'messages' => 3,
    'company_resources' => 7,
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard | APS Dream Homes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; }
        .dashboard-card { border-radius: 1rem; box-shadow: 0 2px 16px rgba(0,0,0,0.08); margin-bottom: 2rem; background: #fff; }
        .feature-icon { font-size: 2.5rem; color: #fd7e14; }
        .dashboard-stats { display: flex; gap: 2rem; flex-wrap: wrap; margin-bottom: 2rem; }
        .stat-box { background: #f8f9fa; border-radius: .5rem; padding: 1.5rem 2rem; min-width: 180px; text-align: center; }
        .ai-chatbot { background: #fff7e6; border-left: 5px solid #fd7e14; padding: 1.5rem; border-radius: .5rem; margin-bottom: 2rem; }
        @media (max-width: 767px) { .dashboard-stats { flex-direction: column; gap: 1rem; } }
    </style>
</head>
<body>
<div class="container py-5">
    <h1 class="mb-4">Welcome, <?php echo $employee_name; ?>!</h1>
    <!-- Stats Cards -->
    <div class="dashboard-stats">
        <div class="stat-box">
            <div class="fs-3 fw-bold text-warning"><?php echo $stats['tasks_today']; ?></div>
            <div>Tasks Today</div>
        </div>
        <div class="stat-box">
            <div class="fs-3 fw-bold text-success"><?php echo $stats['attendance_days']; ?></div>
            <div>Attendance Days</div>
        </div>
        <div class="stat-box">
            <div class="fs-3 fw-bold text-primary"><?php echo $stats['messages']; ?></div>
            <div>Messages</div>
        </div>
        <div class="stat-box">
            <div class="fs-3 fw-bold text-info"><?php echo $stats['company_resources']; ?></div>
            <div>Company Resources</div>
        </div>
    </div>
    <!-- AI Chatbot Panel -->
    <div class="ai-chatbot mb-4">
        <strong><i class="fa-solid fa-robot"></i> Ask AI (Chatbot):</strong>
        <form id="aiChatForm" class="d-flex mt-2" onsubmit="return false;">
            <input type="text" class="form-control me-2" id="aiChatInput" placeholder="Ask about tasks, attendance, or HR policies...">
            <button class="btn btn-warning" onclick="sendAIQuery()"><i class="fa-solid fa-paper-plane"></i></button>
        </form>
        <div id="aiChatResponse" class="mt-2 text-secondary small">Try: "Show my pending tasks"</div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center">
                <i class="fa-solid fa-user-tie feature-icon"></i>
                <h4 class="mt-3">My Tasks</h4>
                <p>View assigned tasks and mark progress.</p>
                <a href="#" class="btn btn-outline-warning">View Tasks</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center">
                <i class="fa-solid fa-calendar-check feature-icon"></i>
                <h4 class="mt-3">Attendance</h4>
                <p>Mark attendance and view attendance history.</p>
                <a href="#" class="btn btn-outline-warning">Mark Attendance</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card p-4 text-center">
                <i class="fa-solid fa-comments feature-icon"></i>
                <h4 class="mt-3">Messages</h4>
                <p>Check messages and notifications from HR/Admin.</p>
                <a href="#" class="btn btn-outline-warning">Go to Inbox</a>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card dashboard-card p-4">
                <h5>Profile & Settings</h5>
                <ul>
                    <li><a href="#">Edit Profile</a></li>
                    <li><a href="#">Change Password</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card dashboard-card p-4">
                <h5>Company Resources</h5>
                <ul>
                    <li><a href="#">Company Policies</a></li>
                    <li><a href="#">Download Forms</a></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- AI Suggestions Panel -->
    <div class="dashboard-card p-4 bg-white rounded shadow-sm">
        <h4 class="mb-3"><i class="fa fa-magic me-2"></i>AI Suggestions & Reminders</h4>
        <div id="aiSuggestionsPanel">
            <div class="text-center text-muted">Loading personalized suggestions...</div>
        </div>
    </div>
    <!-- Export & Share -->
    <div class="dashboard-card">
        <h4><i class="fa-solid fa-share-nodes"></i> Export & Share</h4>
        <button class="btn btn-outline-secondary me-2"><i class="fa-solid fa-file-csv"></i> Export CSV</button>
        <button class="btn btn-outline-secondary me-2"><i class="fa-solid fa-file-pdf"></i> Export PDF</button>
        <button class="btn btn-outline-secondary"><i class="fa-solid fa-qrcode"></i> Share via QR</button>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
// AI Chatbot JS (simulate response)
function sendAIQuery() {
    const input = document.getElementById('aiChatInput').value.trim();
    if (!input) return;
    document.getElementById('aiChatResponse').innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Thinking...';
    setTimeout(() => {
        document.getElementById('aiChatResponse').innerHTML = '<b>AI:</b> This is a sample AI-powered answer to: <code>' + input + '</code>';
    }, 1200);
}
// AI Suggestions Panel (AJAX)
function logAIInteraction(action, suggestion, feedback, notes) {
    $.post('admin/log_ai_interaction.php', {
        action: action,
        suggestion: suggestion,
        feedback: feedback||'',
        notes: notes||''
    });
}
$(function(){
    $.get('user_ai_suggestions.php', function(resp) {
        if(resp.success) {
            let html = '';
            if(resp.status && resp.status.length) {
                html += '<div class="mb-2"><b>Reminders:</b><ul>';
                resp.status.forEach(function(rem) { html += '<li>'+rem+' <span class="badge bg-light text-dark pointer ms-1" onclick="logAIInteraction(\'feedback\', `'+rem.replace(/'/g,"&#39;")+'`,\'like\')">👍</span> <span class="badge bg-light text-dark pointer" onclick="logAIInteraction(\'feedback\', `'+rem.replace(/'/g,"&#39;")+'`,\'dislike\')">👎</span></li>'; });
                html += '</ul></div>';
            }
            if(resp.suggestions && resp.suggestions.length) {
                html += '<div><b>AI Suggestions:</b><ul>';
                resp.suggestions.forEach(function(sugg) { html += '<li>'+sugg+' <span class="badge bg-light text-dark pointer ms-1" onclick="logAIInteraction(\'feedback\', `'+sugg.replace(/'/g,"&#39;")+'`,\'like\')">👍</span> <span class="badge bg-light text-dark pointer" onclick="logAIInteraction(\'feedback\', `'+sugg.replace(/'/g,"&#39;")+'`,\'dislike\')">👎</span></li>'; });
                html += '</ul></div>';
            }
            if(!html) html = '<div class="text-success">You are all caught up!</div>';
            $('#aiSuggestionsPanel').html(html);
            if(resp.suggestions) resp.suggestions.forEach(function(sugg){ logAIInteraction('view', sugg); });
            if(resp.status) resp.status.forEach(function(rem){ logAIInteraction('view', rem); });
        } else {
            $('#aiSuggestionsPanel').html('<div class="text-danger">Could not load suggestions.</div>');
        }
    },'json');
});
</script>
</body>
</html>
