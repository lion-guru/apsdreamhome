<?php echo 'Router test - URL: ' . ($_GET['url'] ?? 'none'); ?>
