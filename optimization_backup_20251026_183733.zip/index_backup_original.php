<?php
/**
 * APS Dream Home - Enhanced Main Entry Point
 * 
 * This file integrates the modern routing system with backward compatibility
 */

// Security check - prevent direct access
if (!defined('INCLUDED_FROM_MAIN')) {
    define('INCLUDED_FROM_MAIN', true);
}

// Start session with enhanced security
if (session_status() === PHP_SESSION_NONE) {
    session_name('APS_DREAM_HOME_SESSID');
    session_set_cookie_params([
        'lifetime' => 86400,
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'] ?? '',
        'secure' => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Set default timezone
date_default_timezone_set('Asia/Kolkata');

// Define base paths
define('ROOT_PATH', __DIR__);
define('APP_PATH', ROOT_PATH . '/app');
define('PUBLIC_PATH', ROOT_PATH);
define('UPLOAD_PATH', ROOT_PATH . '/uploads');

// Define base URL with subfolder support
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domainName = $_SERVER['HTTP_HOST'];
$scriptPath = dirname($_SERVER['SCRIPT_NAME']);
$base_url = $protocol . $domainName . $scriptPath;

if (!defined('BASE_URL')) {
    define('BASE_URL', rtrim($base_url, '/'));
}

// Load routing configuration
$routingConfig = require_once 'routing_config.php';

// Determine environment
$environment = isset($_SERVER['ENVIRONMENT']) ? $_SERVER['ENVIRONMENT'] : 'development';
$config = array_merge($routingConfig['routing'], $routingConfig[$environment]);

// Error reporting based on environment
if ($environment === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ERROR | E_WARNING | E_PARSE);
    ini_set('display_errors', 0);
}

// Load configuration and functions
require_once 'includes/config.php';
require_once 'includes/functions.php';

/**
 * Enhanced Routing System
 */
try {
    // Check if modern routing is enabled
    if ($config['enabled'] && $config['default_system'] !== 'legacy') {
        
        // Load modern application bootstrap
        if (file_exists(APP_PATH . '/bootstrap.php')) {
            require_once APP_PATH . '/bootstrap.php';
            
            // Initialize the application
            if (class_exists('App')) {
                $app = new App();
                $app->bootstrap();
            }
        }
        
        // Use modern route loader
        if (file_exists(ROOT_PATH . '/route_loader.php')) {
            require_once ROOT_PATH . '/route_loader.php';
            
            // The route_loader.php will handle the routing
            exit;
        }
    }
    
    // Fallback to legacy routing system
    if (file_exists(ROOT_PATH . '/router.php')) {
        require_once ROOT_PATH . '/router.php';
        exit;
    }
    
    // Ultimate fallback - show homepage
    if (file_exists(ROOT_PATH . '/index_modern.php')) {
        require_once ROOT_PATH . '/index_modern.php';
        exit;
    }
    
    // Final fallback - basic homepage
    require_once ROOT_PATH . '/homepage.php';
    
} catch (Exception $e) {
    // Handle routing errors
    error_log("Routing error: " . $e->getMessage());
    
    // Show user-friendly error page
    http_response_code(500);
    
    $errorMessage = $environment === 'development' ? htmlspecialchars($e->getMessage()) : 'An error occurred while processing your request.';
    
    echo '<!DOCTYPE html>
<html>
<head>
    <title>Application Error</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            text-align: center; 
            padding: 50px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .error-container {
            background: rgba(255,255,255,0.1);
            padding: 40px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            max-width: 600px;
            width: 90%;
        }
        h1 { 
            color: #ff6b6b; 
            margin-bottom: 20px;
            font-size: 2.5em;
        }
        p {
            font-size: 1.1em;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .back-link { 
            color: #4ecdc4; 
            text-decoration: none; 
            font-weight: bold;
            padding: 12px 24px;
            border: 2px solid #4ecdc4;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
            transition: all 0.3s ease;
            font-size: 1.1em;
        }
        .back-link:hover {
            background: #4ecdc4;
            color: white;
            transform: translateY(-2px);
        }
        .error-details {
            background: rgba(0,0,0,0.2);
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            font-family: monospace;
            font-size: 12px;
            border-left: 4px solid #ff6b6b;
            text-align: left;
        }
        .error-icon {
            font-size: 4em;
            color: #ff6b6b;
            margin-bottom: 20px;
        }
        .support-info {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-icon">⚠️</div>
        <h1>Application Error</h1>
        <p>We apologize, but the application encountered an error while processing your request.</p>
        
        ' . ($environment === 'development' ? '<div class="error-details">' . $errorMessage . '</div>' : '') . '
        
        <p>Please try again in a few moments, or contact support if the problem persists.</p>
        
        <a href="' . BASE_URL . '" class="back-link">🏠 Go back to homepage</a>
        
        <div class="support-info">
            <strong>Need help?</strong><br>
            Contact our support team at: <a href="mailto:support@apsdreamhome.com" style="color: #4ecdc4;">support@apsdreamhome.com</a><br>
            Phone: <a href="tel:+91-1234567890" style="color: #4ecdc4;">+91-1234567890</a>
        </div>
    </div>
</body>
</html>';
    exit;
}