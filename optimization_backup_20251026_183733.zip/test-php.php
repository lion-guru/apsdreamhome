@<?php echo "<h1>TEST PAGE - PHP IS WORKING</h1>"; phpinfo(); ?>
